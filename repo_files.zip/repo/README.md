# The Ansible AIOps Playbook
### Building Self-Healing Linux Systems at Scale

<p align="center">
  <img src="https://img.shields.io/badge/Publisher-Apress%20%2F%20Springer%20Nature-blue?style=flat-square" />
  <img src="https://img.shields.io/badge/Author-Balaramakrishna%20Alti-informational?style=flat-square" />
  <img src="https://img.shields.io/badge/License-MIT-green?style=flat-square" />
  <img src="https://img.shields.io/badge/Ansible-2.15%2B-red?style=flat-square" />
  <img src="https://img.shields.io/badge/Python-3.11%2B-yellow?style=flat-square" />
  <img src="https://img.shields.io/badge/RHEL%2FRocky-9-lightgrey?style=flat-square" />
</p>

---

## About This Book

**"The Ansible AIOps Playbook: Building Self-Healing Linux Systems at Scale"** is a
practitioner's guide to integrating Artificial Intelligence, Large Language Models,
Linux administration, and Ansible automation to build intelligent, self-healing
enterprise infrastructure.

Written by a Systems Engineer with 16+ years of enterprise Linux experience at
Fortune 500 companies including Moody's Corporation, Walgreens, CNA Insurance,
and Agilent/Keysight Technologies — every pattern and technique in this book
has been validated in production environments managing 8,000+ servers globally.

**Publisher:** Apress / Springer Nature  
**Author:** Balaramakrishna Alti  
**Contact:** balaramaa@gmail.com  
**LinkedIn:** [linkedin.com/in/balaramakrishna-alti-b9924b278](https://www.linkedin.com/in/balaramakrishna-alti-b9924b278)

---

## Repository Structure

```
ansible-aiops-playbook/
│
├── chapters/
│   ├── ch01-lab-setup/                  # Chapter 1:  The Intelligent Infrastructure Imperative
│   ├── ch02-linux-foundations/          # Chapter 2:  Linux Infrastructure Automation Foundations
│   ├── ch03-ansible-architecture/       # Chapter 3:  Ansible Architecture for Enterprise Scale
│   ├── ch04-llm-playbook-generation/    # Chapter 4:  AI-Assisted Playbook Generation with LLMs
│   ├── ch05-compliance-governance/      # Chapter 5:  AI-Powered Compliance and Governance
│   ├── ch06-patch-management/           # Chapter 6:  Predictive Patch Management
│   ├── ch07-self-healing/               # Chapter 7:  Self-Healing Infrastructure Design Patterns
│   ├── ch08-security-automation/        # Chapter 8:  Intelligent Security Automation
│   ├── ch09-cloud-hybrid/               # Chapter 9:  Cloud and Hybrid Infrastructure Automation
│   ├── ch10-cicd-pipelines/             # Chapter 10: CI/CD Pipelines for Infrastructure Automation
│   ├── ch11-observability/              # Chapter 11: Observability, Telemetry, and AI Analytics
│   ├── ch12-migration/                  # Chapter 12: Large-Scale Migration and Acquisition Integration
│   ├── ch13-aiops-platform/             # Chapter 13: AIOps Platform Architecture
│   └── ch14-future/                     # Chapter 14: The Autonomous Infrastructure Future
│
├── appendices/
│   ├── appendix-a-lab-setup/            # Full lab environment setup guide
│   ├── appendix-b-ansible-reference/    # Ansible modules, filters, callbacks quick reference
│   ├── appendix-c-cis-mapping/          # CIS Benchmark controls mapped to playbooks
│   ├── appendix-d-prompt-library/       # LLM prompt library for infrastructure automation
│   └── appendix-e-resources/            # Recommended reading and online resources
│
└── shared/
    ├── roles/                           # Reusable Ansible roles used across multiple chapters
    ├── modules/                         # Custom Ansible modules
    ├── inventory-plugins/               # Custom inventory plugins
    └── filters/                         # Custom Jinja2 filter plugins
```

---

## Quick Start

### Prerequisites

| Component | Minimum Version | Purpose |
|-----------|----------------|---------|
| RHEL / Rocky Linux | 9.x | Control + managed nodes |
| ansible-core | 2.15+ | Automation engine |
| Python | 3.11+ | AI/LLM scripts |
| Terraform | 1.5+ | AWS lab provisioning (optional) |
| Git | 2.x | Version control |

### 1. Clone This Repository

```bash
git clone https://github.com/balaramaa/ansible-aiops-playbook.git
cd ansible-aiops-playbook
```

### 2. Set Up Your Lab

**Local (VirtualBox/KVM):**
```bash
# On your control node
sudo ./chapters/ch01-lab-setup/scripts/setup_control_node.sh

# On each managed node
sudo ./chapters/ch01-lab-setup/scripts/setup_managed_nodes.sh
```

**AWS (auto-provisioned):**
```bash
cd chapters/ch01-lab-setup/terraform/
terraform init && terraform apply
```

### 3. Validate Your Environment

```bash
./chapters/ch01-lab-setup/scripts/validate_lab.sh
```

### 4. Test LLM Connectivity (required from Chapter 4)

```bash
export OPENAI_API_KEY="sk-..."          # OpenAI (optional)
export ANTHROPIC_API_KEY="sk-ant-..."   # Anthropic (optional)
# Ollama is free and requires no API key — see Chapter 4

python3 chapters/ch01-lab-setup/scripts/test_llm_connectivity.py
```

---

## Chapter Overview

| # | Chapter | Key Technologies |
|---|---------|-----------------|
| 1 | The Intelligent Infrastructure Imperative | Lab setup, Terraform, Ollama |
| 2 | Linux Infrastructure Automation Foundations | eBPF, systemd, SSH, auditd |
| 3 | Ansible Architecture for Enterprise Scale | AAP, Collections, Vault, Satellite |
| 4 | AI-Assisted Playbook Generation with LLMs | OpenAI, Anthropic, Ollama, Python |
| 5 | AI-Powered Compliance and Governance | OpenSCAP, CIS, NIST, SOX |
| 6 | Predictive Patch Management | Red Hat Satellite, CVE scoring, AI |
| 7 | Self-Healing Infrastructure | Event-Driven Ansible, EDA, Rulebooks |
| 8 | Intelligent Security Automation | auditd, eBPF, PAM, SIEM |
| 9 | Cloud and Hybrid Infrastructure | AWS, VMware, Nutanix, Terraform |
| 10 | CI/CD Pipelines for Infrastructure | Molecule, GitHub Actions, Jenkins |
| 11 | Observability, Telemetry, AI Analytics | Prometheus, Grafana, ELK, ML |
| 12 | Large-Scale Migration and Acquisition | Discovery, migration playbooks |
| 13 | AIOps Platform Architecture | ML pipelines, feedback loops |
| 14 | The Autonomous Infrastructure Future | Agentic AI, infrastructure LLMs |

---

## LLM Provider Support

All AI exercises support three providers — at least one is required from Chapter 4:

| Provider | Cost | Setup | Best For |
|----------|------|-------|----------|
| [OpenAI](https://platform.openai.com) | Pay-per-use | API key | Best quality output |
| [Anthropic](https://console.anthropic.com) | Pay-per-use | API key | Strong reasoning |
| [Ollama](https://ollama.com) | **Free** | Local install | Air-gapped / offline |

---

## Related Research

This book is grounded in peer-reviewed research by the author:

- Alti, B. (2024). *AI-Powered Governance-as-Code for Secure Linux Operations in FinTech Infrastructure.* Computer Fraud & Security, Elsevier.
- Alti, B. (2024). *Autonomous Compliance Governance for Linux Infrastructure Using AI-Based Control Models.* Journal of Information Systems Engineering and Management.
- Alti, B. (2024). *Predictive Risk-Aware Patch Governance Using Artificial Intelligence.* Contemporary Readings in Law and Social Justice.

[Google Scholar Profile](https://scholar.google.com/citations?user=KmRHg_YAAAAJ&hl=en) | [ORCID: 0009-0003-1561-4582](https://orcid.org/0009-0003-1561-4582)

---

## Intellectual Property

- 🇩🇪 German Utility Model — Linux Security Remediation System (Granted 2026)
- 🇬🇧 UK Registered Design — Linux Monitoring Device (Granted 2026)
- 🇬🇧 UK Registered Design — Server Compliance Visualization Device (Granted 2026)

---

## Contributing and Errata

Found an error or have a suggestion?

1. Open an [Issue](https://github.com/balaramaa/ansible-aiops-playbook/issues)
2. Submit a [Pull Request](https://github.com/balaramaa/ansible-aiops-playbook/pulls)

Errata will be published as releases and noted in the book's Apress page.

---

## License

MIT License — see [LICENSE](LICENSE) for details.

Source code in this repository is free to use and adapt for personal and
commercial purposes with attribution. Book text is copyright
© Balaramakrishna Alti / Apress Media, LLC. All rights reserved.

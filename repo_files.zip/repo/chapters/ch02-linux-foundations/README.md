# Chapter 2 — Linux Infrastructure Automation Foundations
### eBPF, systemd, SSH hardening, and fleet management at scale

Source code for **Chapter 2** of
*The Ansible AIOps Playbook: Building Self-Healing Linux Systems at Scale*
**Author:** Balaramakrishna Alti | **Publisher:** Apress / Springer Nature
**Repository:** https://github.com/balaramaa/ansible-aiops-playbook

---

## Contents

```
ch02-linux-foundations/
├── ebpf/                        # eBPF programs for kernel-level observability
│   ├── trace_syscalls.py        # Trace system calls with bpftrace
│   ├── monitor_file_opens.bt    # Monitor file open events
│   └── cpu_profile.bt           # CPU profiling script
├── systemd/
│   ├── unit-files/              # Example systemd service and timer units
│   └── timers/                  # Systemd timer examples for scheduled tasks
├── ssh-hardening/               # SSH configuration hardening scripts and playbooks
├── auditd/                      # auditd rules for security monitoring
├── fleet-management/            # Patterns for managing large server fleets
└── scripts/                     # Supporting shell scripts for chapter exercises
```

> **Status:** 🔄 Content added as chapter is written.

---

## Key Concepts Covered

- Enterprise Linux distributions: RHEL 9, Rocky Linux 9, SUSE
- Kernel-level observability with eBPF and bpftrace
- systemd: unit files, timers, targets, and service orchestration
- SSH hardening: disabling root login, key-based auth, idle timeouts
- auditd rules for compliance and security monitoring
- Managing large server fleets without automation tools (baseline)

---

## Prerequisites

```bash
# Install bpftrace for eBPF exercises
sudo dnf install -y bpftrace bcc-tools kernel-devel

# Verify eBPF support
sudo bpftrace -e 'BEGIN { printf("eBPF working\n"); exit(); }'
```

---

*Part of [The Ansible AIOps Playbook](https://github.com/balaramaa/ansible-aiops-playbook) — Apress / Springer Nature*

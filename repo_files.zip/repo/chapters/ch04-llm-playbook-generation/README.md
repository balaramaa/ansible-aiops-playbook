# Chapter 4 — AI-Assisted Playbook Generation with LLMs
### OpenAI, Anthropic, and Ollama integrations for infrastructure automation

Source code for **Chapter 4** of
*The Ansible AIOps Playbook: Building Self-Healing Linux Systems at Scale*
**Author:** Balaramakrishna Alti | **Publisher:** Apress / Springer Nature
**Repository:** https://github.com/balaramaa/ansible-aiops-playbook

---

## Contents

```
ch04-llm-playbook-generation/
├── openai/                      # OpenAI API integration scripts
├── anthropic/                   # Anthropic Claude API integration scripts
├── ollama/                      # Local LLM via Ollama (air-gapped environments)
├── prompt-library/              # Reusable prompts for common infrastructure tasks
├── playbook-review/             # AI-powered playbook review and security scanning
└── documentation-generator/    # Auto-generate docs from existing playbooks
```

> **Status:** 🔄 Content added as chapter is written.

---

## Key Concepts Covered

- LLM fundamentals for infrastructure engineers
- Prompt engineering for Ansible and YAML generation
- Integrating OpenAI (GPT-4o) and Anthropic (Claude) APIs
- Local LLMs with Ollama for air-gapped enterprise deployment
- Automated playbook review and security scanning with AI
- LLM-generated infrastructure documentation
- Building a reusable prompt library

---

## Environment Setup

```bash
# Required: at least one LLM provider
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."

# Free alternative: Ollama (no API key needed)
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3

# Install Python dependencies
pip3 install openai anthropic requests pyyaml
```

---

*Part of [The Ansible AIOps Playbook](https://github.com/balaramaa/ansible-aiops-playbook) — Apress / Springer Nature*

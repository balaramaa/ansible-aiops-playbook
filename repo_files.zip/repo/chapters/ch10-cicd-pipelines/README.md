# Chapter 10 — CI/CD Pipelines for Infrastructure Automation
### Molecule, GitHub Actions, Jenkins — treating infrastructure as software

Source code for **Chapter 10** of
*The Ansible AIOps Playbook: Building Self-Healing Linux Systems at Scale*
**Author:** Balaramakrishna Alti | **Publisher:** Apress / Springer Nature
**Repository:** https://github.com/balaramaa/ansible-aiops-playbook

---

## Contents

```
ch10-cicd-pipelines/
├── github-actions/              # GitHub Actions workflows for Ansible
├── jenkins/                     # Jenkins pipeline definitions (Jenkinsfile)
├── gitlab-ci/                   # GitLab CI/CD pipeline configs
├── molecule/                    # Molecule test scenarios for Ansible roles
├── ansible-lint/                # Linting configuration and custom rules
├── vault-injection/             # HashiCorp Vault integration in pipelines
└── blue-green/                  # Blue/green deployment patterns for infra
```

> **Status:** 🔄 Content added as chapter is written.

---

## Key Concepts Covered

- GitOps for infrastructure: branching strategies and review gates
- Testing Ansible roles with Molecule and Testinfra
- Linting and static analysis: ansible-lint, yamllint, and AI review
- Pipeline design with Jenkins, GitLab CI, and GitHub Actions
- Blue/green deployments for infrastructure changes
- Secrets injection: HashiCorp Vault integration
- Rollback strategies and change freeze automation

---

## Prerequisites

```bash
# Molecule and testing tools
pip3 install molecule molecule-plugins[docker] pytest-testinfra

# Linting tools
pip3 install ansible-lint yamllint

# Verify
molecule --version && ansible-lint --version
```

---

*Part of [The Ansible AIOps Playbook](https://github.com/balaramaa/ansible-aiops-playbook) — Apress / Springer Nature*

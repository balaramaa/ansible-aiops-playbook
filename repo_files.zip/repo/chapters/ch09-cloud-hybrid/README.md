# Chapter 9 — Cloud and Hybrid Infrastructure Automation
### AWS, VMware, and Nutanix — unified automation across hybrid environments

Source code for **Chapter 9** of
*The Ansible AIOps Playbook: Building Self-Healing Linux Systems at Scale*
**Author:** Balaramakrishna Alti | **Publisher:** Apress / Springer Nature
**Repository:** https://github.com/balaramaa/ansible-aiops-playbook

---

## Contents

```
ch09-cloud-hybrid/
├── aws/
│   ├── ec2/                     # EC2 instance management playbooks
│   ├── iam/                     # IAM role and policy automation
│   ├── vpc/                     # VPC networking automation
│   └── s3/                      # S3 bucket management
├── vmware/                      # VMware vSphere automation with Ansible
├── nutanix/                     # Nutanix AHV and Prism API integration
├── hybrid-inventory/            # Unified inventory across hybrid environments
├── cost-governance/             # AI-driven cost optimization scripts
└── terraform-ansible/           # Ansible + Terraform collaboration patterns
```

> **Status:** 🔄 Content added as chapter is written.

---

## Key Concepts Covered

- Hybrid infrastructure topology: on-prem, AWS, VMware, Nutanix
- Ansible AWS modules: EC2, IAM, VPC, S3 at scale
- VMware vSphere automation with Ansible
- Nutanix AHV and Prism API integration
- Unified inventory management across hybrid environments
- Cost governance and resource optimization with AI
- Infrastructure as Code: Ansible + Terraform collaboration

---

## Prerequisites

```bash
# AWS collections
ansible-galaxy collection install amazon.aws community.aws

# VMware collections
ansible-galaxy collection install community.vmware

# Python dependencies
pip3 install boto3 botocore pyvmomi
```

---

*Part of [The Ansible AIOps Playbook](https://github.com/balaramaa/ansible-aiops-playbook) — Apress / Springer Nature*

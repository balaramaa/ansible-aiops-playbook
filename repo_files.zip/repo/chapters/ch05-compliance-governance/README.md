# Chapter 5 — AI-Powered Compliance and Governance Automation
### CIS, NIST, SOX, PCI-DSS — autonomous compliance at enterprise scale

Source code for **Chapter 5** of
*The Ansible AIOps Playbook: Building Self-Healing Linux Systems at Scale*
**Author:** Balaramakrishna Alti | **Publisher:** Apress / Springer Nature
**Repository:** https://github.com/balaramaa/ansible-aiops-playbook

---

## Contents

```
ch05-compliance-governance/
├── playbooks/                   # Governance-as-code playbooks
├── openscap/                    # OpenSCAP integration and SCAP content
├── drift-detection/             # AI-based configuration drift detection
├── remediation/                 # Automated remediation playbooks with rollback
├── reports/                     # Audit trail generation and regulatory reporting
└── cis-benchmarks/              # CIS Level 1 and 2 benchmark implementations
```

> **Status:** 🔄 Content added as chapter is written.

---

## Key Concepts Covered

- Compliance frameworks: CIS Benchmarks, NIST 800-53, SOX, PCI-DSS
- Governance-as-Code: encoding policy in Ansible
- AI-based drift detection and anomaly classification
- Continuous compliance with SCAP and OpenSCAP integration
- Automated remediation playbooks with rollback capability
- Audit trail generation and regulatory reporting
- Case Study: 100% compliance across 4,500+ servers at Moody's Corporation

---

## Prerequisites

```bash
# Install OpenSCAP tools
sudo dnf install -y openscap-scanner scap-security-guide

# Verify OpenSCAP installation
oscap --version

# Download CIS content (requires Red Hat subscription or community SCAP content)
ls /usr/share/xml/scap/ssg/content/
```

---

*Part of [The Ansible AIOps Playbook](https://github.com/balaramaa/ansible-aiops-playbook) — Apress / Springer Nature*

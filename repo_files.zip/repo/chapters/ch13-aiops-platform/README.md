# Chapter 13 — AIOps Platform Architecture
### Building a production AIOps platform from telemetry to autonomous action

Source code for **Chapter 13** of
*The Ansible AIOps Playbook: Building Self-Healing Linux Systems at Scale*
**Author:** Balaramakrishna Alti | **Publisher:** Apress / Springer Nature
**Repository:** https://github.com/balaramaa/ansible-aiops-playbook

---

## Contents

```
ch13-aiops-platform/
├── ml-pipeline/
│   ├── data-collection/         # Telemetry collection pipelines
│   ├── feature-engineering/     # Feature extraction from infrastructure data
│   ├── model-training/          # ML model training scripts
│   └── model-serving/           # Model serving and inference API
├── aap-integration/             # Ansible Automation Platform integration
├── feedback-loops/              # Continuous learning from operational data
├── dashboards/                  # AIOps platform dashboards
└── data-engineering/            # Feature stores and data pipelines
```

> **Status:** 🔄 Content added as chapter is written.

---

## Key Concepts Covered

- AIOps reference architecture
- Building an ML pipeline for infrastructure anomaly detection
- Integrating AI models with Ansible Automation Platform
- Feedback loops: continuous learning from operational data
- Open-source AIOps tools overview
- Data engineering for infrastructure AI: feature engineering
- Governance and explainability in automated decisions

---

*Part of [The Ansible AIOps Playbook](https://github.com/balaramaa/ansible-aiops-playbook) — Apress / Springer Nature*

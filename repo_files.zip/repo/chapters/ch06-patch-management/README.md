# Chapter 6 — Predictive Patch Management and Risk Governance
### AI-driven CVE prioritization and autonomous patching at scale

Source code for **Chapter 6** of
*The Ansible AIOps Playbook: Building Self-Healing Linux Systems at Scale*
**Author:** Balaramakrishna Alti | **Publisher:** Apress / Springer Nature
**Repository:** https://github.com/balaramaa/ansible-aiops-playbook

---

## Contents

```
ch06-patch-management/
├── playbooks/                   # Patching playbooks for RHEL/Rocky fleets
├── cve-scoring/                 # AI-based CVE risk scoring scripts
├── satellite/                   # Red Hat Satellite integration
├── canary-patching/             # Canary patching and phased rollout patterns
├── rollback/                    # Automated rollback strategies
└── dashboard/                   # Patch governance dashboard
```

> **Status:** 🔄 Content added as chapter is written.

---

## Key Concepts Covered

- The patching problem at scale: downtime, risk, and velocity
- Red Hat Satellite: content views, lifecycle environments, errata
- AI-based CVE risk scoring with CVSS and exploit probability
- Predictive maintenance windows using historical telemetry
- Canary patching and automated rollback strategies
- Integration with Tenable, Qualys, and Prisma vulnerability scanners
- Building a patch governance dashboard

---

*Part of [The Ansible AIOps Playbook](https://github.com/balaramaa/ansible-aiops-playbook) — Apress / Springer Nature*
